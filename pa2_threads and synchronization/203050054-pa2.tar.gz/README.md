# CS744 - Assignment 2 - Threads and Synchronization

### Student Details

* Name: Fenil Mehta
* Roll Number: 203050054

#### Please refer `README.md` under each folder for more details about specific question and solution
1. [Hello pthreads](./1_hello%20pthreads)
2. [Just a barrier away](./2_barrier)
3. [Hare and Turtle race](./3_race)
