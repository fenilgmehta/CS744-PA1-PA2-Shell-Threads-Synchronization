#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "barrier.h"

void barrier_init(struct barrier_t * barrier, int nthreads)
{
	/*
		Todo
	*/
	return;
}

void barrier_wait(struct barrier_t *barrier)
{
	/*
		Todo
	*/
	return;
}